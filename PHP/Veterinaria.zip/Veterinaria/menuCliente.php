<?php


session_start();

    $dniCliSel = $_SESSION['$dniCliSel'];
    $password = $_SESSION['$password'];
            
        print"<a href='mascota.php' title='Crear mascota'><br>";
        print "<a href='tipo.php'>Realizar Compra</a><br>";
    
            
?>

