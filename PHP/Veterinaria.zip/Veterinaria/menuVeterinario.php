<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>
        
        
        </h2>
        <?php
        
        $form=<<<FORM
            <a href='cliente.php' title='Crear cliente'><br>
            <a href='mascota.php'>Crear mascota</a><br>
            <a href='veterinario.php'>Crear veterinario</a><br>    
            <a href='tipo.php'>Crear tipo</a><br>
            <a href='tarea.php'>Crear tarea</a><br> 
                
FORM;
        print $form;
        ?>
    </body>
</html>
